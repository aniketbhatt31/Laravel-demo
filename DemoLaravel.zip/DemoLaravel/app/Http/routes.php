<?php
Route::resource('productCRUD','ProductCRUDController');